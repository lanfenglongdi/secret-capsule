module.exports = {
    reactStrictMode: true
  };