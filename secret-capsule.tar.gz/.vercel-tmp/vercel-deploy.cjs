#!/usr/bin/env node
const { spawnSync } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const isWindows = os.platform() === 'win32';

function log(msg) { console.error(msg); }

function commandExists(cmd) {
  try {
    if (isWindows) {
      return spawnSync('where', [cmd], { stdio: 'ignore' }).status === 0;
    } else {
      return spawnSync('sh', ['-c', `command -v "$1"`, '--', cmd], { stdio: 'ignore' }).status === 0;
    }
  } catch { return false; }
}

function main() {
  log('========================================');
  log('Vercel Deployment Script');
  log('========================================\n');

  // Check if logged in
  const whoamiResult = spawnSync('npx', ['vercel', 'whoami'], { encoding: 'utf8', stdio: ['pipe', 'pipe', 'pipe'], shell: isWindows });
  if (whoamiResult.status !== 0 || whoamiResult.stdout.includes('not logged in')) {
    log('Error: Not logged in to Vercel');
    log('Please run login script first');
    process.exit(1);
  }
  log(`Logged in as: ${(whoamiResult.stdout || '').trim()}\n`);

  // Deploy with environment variables
  log('Starting deployment with environment variables...');
  log('');

  const envVars = [
    '-e', 'SUPABASE_URL=https://fgushinpapaczugfztfg.supabase.co',
    '-e', 'SUPABASE_KEY=sb_publishable_c9tGHJ__pEpJoBoaTWJg6w_Jc1PPf7f'
  ];

  const result = spawnSync('npx', ['vercel', '--prod', '--yes', ...envVars], {
    cwd: process.cwd(),
    encoding: 'utf8',
    stdio: ['inherit', 'pipe', 'pipe'],
    timeout: 300000,
    shell: isWindows
  });

  const output = (result.stdout || '') + (result.stderr || '');
  log(output);

  if (result.status !== 0) {
    log('\nDeployment failed');
    process.exit(1);
  }

  // Extract URL
  const urlMatch = output.match(/Production:\s*(https:\/\/[^\s]+)/i) || output.match(/Aliased:\s*(https:\/\/[^\s]+)/i);
  if (urlMatch) {
    log('\n========================================');
    log('Deployment successful!');
    log('========================================');
    log(`\nYour site is live at: ${urlMatch[1]}`);
    console.log(JSON.stringify({ status: 'success', url: urlMatch[1] }));
  } else {
    console.log(JSON.stringify({ status: 'success', message: 'Deployment completed' }));
  }
}

main();
